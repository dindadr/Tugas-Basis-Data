<?php
$host = "localhost";
$user = "dinda";
$pass = "312010141";
$db = "klinik_312010141";

$koneksi = mysqli_connect($host, $user, $pass, $db);